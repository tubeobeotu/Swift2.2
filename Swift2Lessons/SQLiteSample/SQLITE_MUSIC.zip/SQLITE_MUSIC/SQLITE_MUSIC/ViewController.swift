//
//  ViewController.swift
//  SQLITE_MUSIC
//
//  Created by Tuuu on 7/22/16.
//  Copyright © 2016 TuNguyen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let dataBase = DataBase()
    }




}

