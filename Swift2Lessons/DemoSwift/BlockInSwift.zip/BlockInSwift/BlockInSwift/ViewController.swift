//
//  ViewController.swift
//  BlockInSwift
//
//  Created by Tuuu on 6/1/16.
//  Copyright © 2016 TuNguyen. All rights reserved.
//

import UIKit
import AVFoundation
class ViewController: UIViewController {
    
    @IBOutlet weak var img_Profile: UIImageView!
    var imgs = ["https://i.ytimg.com/vi/yIZlTHgfFYw/maxresdefault.jpg", "http://news.xinhuanet.com/fashion/2012-12/19/124106746_131n.jpg",
                "https://s-media-cache-ak0.pinimg.com/736x/3f/a1/62/3fa162dbd33effa671b5e5a820952c88.jpg", "http://top10for.com/wp-content/uploads/2015/02/Hottest-Victoria%E2%80%99s-Secret-Models1.jpg"]
    
    var block:(() -> ())?
    let noP = {() -> () in
        print("1")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        noP()
    }
    @IBAction func a_print(sender: AnyObject)
    {
        makeSound(1, block: { (value) in
        })
    }
    func makeSound(x: Int, block: (value: String) -> ())
    {
        print("123")
    }
    func loadData(complete:(data: NSData, index: Int)->())
    {
        dispatch_async(dispatch_get_global_queue(0, 0), {
            for stringUrl in self.imgs
            {
                if let url = NSURL(string: stringUrl)
                {
                    if let data = NSData(contentsOfURL: url) {
                        complete(data: data, index: self.imgs.indexOf(stringUrl)!)
                    }
                }
            }
        })
    }
    @IBAction func play(sender: AnyObject)
    {
        loadData({ (data, index) in
            dispatch_async(dispatch_get_main_queue(), {
                if let imgView = self.view.viewWithTag(100+index) as? UIImageView
                {
                    imgView.image = UIImage(data: data)
                }
            })
        })
        
    }
}

