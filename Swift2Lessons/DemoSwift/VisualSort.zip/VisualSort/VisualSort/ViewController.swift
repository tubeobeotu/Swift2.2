//
//  ViewController.swift
//  VisualSort
//
//  Created by Tuuu on 5/20/16.
//  Copyright © 2016 TuNguyen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var array = [9, 8, 7, 6, 5, 4]
    var arrayView = [CustomView]()
    var i = 0
    var j = 1
    override func viewDidLoad() {
        super.viewDidLoad()
        self.addView()
        self.sort()
        
    }
    func sort()
    {
        if (self.i == self.arrayView.count-1)
        {
            return
        }
        
        if (arrayView[i].value > arrayView[j].value)
        {

                    let tempViewX = self.arrayView[self.i].center.x
                    let tempViewY = self.arrayView[self.i].center.y
                    UIView.animateWithDuration(0.5, animations: {
                        self.arrayView[self.i].center = CGPoint(x: self.arrayView[self.j].center.x, y: self.arrayView[self.j].center.y)
                        }, completion: { (finished) in
                            UIView.animateWithDuration(0.5, animations: {
                                self.arrayView[self.j].center = CGPoint(x: tempViewX, y: tempViewY)
                                let tempValue = self.arrayView[self.i].value
                                print(tempValue)
                                self.arrayView[self.i].value = self.arrayView[self.j].value
                                self.arrayView[self.j].value = tempValue
                                
                                }, completion: { (finished) in
                                    if (self.j == self.arrayView.count - 1)
                                    {
                                        self.j = 0
                                        if (self.i < self.arrayView.count)
                                        {
                                            self.i = self.i + 1
                                            self.j = self.i + 1
                                        }
                                    }
                                    else
                                    {
                                        self.j = self.j + 1
                                    }
                                    self.sort()
                            })
                    })
        }
        else
        {
            if (i < arrayView.count - 1)
            {
                
                if (j < arrayView.count - 1)
                {
                    j = j + 1
                }
                else
                {
                    j = 0
                    i = i + 1
                }
                sort()
            }
        }
        
    }
   
    func addView()
    {
        let max = array.maxElement()
        var i = 0
        for value in array
        {
            let height:CGFloat = (CGFloat(value)/CGFloat(max!)) * 100
            let width = 30
            let subView = CustomView(frame: CGRectMake(CGFloat(i) * CGFloat(width) + 100, 200 + (100 - height), CGFloat(width), CGFloat(height)))
            subView.active = false
            subView.sorted = false
            subView.value = value
            subView.layer.borderWidth = 2
            subView.layer.borderColor = UIColor.greenColor().CGColor
            arrayView.append(subView)
            self.view.addSubview(subView)
            i = i + 1
        }
    }
}

